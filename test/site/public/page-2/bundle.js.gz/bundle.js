/** @webqit/webflo */
var{start:s}=WebQit.Webflo,e={},r={bundle_filename:"bundle.js",public_base_url:"/",address_bar_synchrony:"standard",oohtml_support:"full",service_worker_support:!0,worker_scope:"/",worker_filename:"worker.js",routing:{scope:"/page-2",subscopes:[],passes:0}};s.call({layout:e,params:r});
