/** @webqit/webflo */
var{start:e}=WebQit.Webflo,r={},o={bundle_filename:"bundle.js",public_base_url:"/",spa_routing:!0,oohtml_support:"full",service_worker_support:!0,worker_scope:"/",worker_filename:"worker.js",routing:{root:"/page-4/subpage",subroots:[],targets:0}};e.call({layout:r,params:o});
