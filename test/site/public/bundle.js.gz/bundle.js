/** @webqit/webflo */
var{start:e}=WebQit.Webflo,s={},r={bundle_filename:"bundle.js",public_base_url:"/",address_bar_synchrony:"standard",oohtml_support:"full",service_worker_support:!0,worker_scope:"/",worker_filename:"worker.js",routing:{scope:"/",subscopes:["/page-2","/page-4/subpage"],passes:1}};e.call({layout:s,params:r});
