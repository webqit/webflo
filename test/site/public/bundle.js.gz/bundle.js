/** @webqit/webflo */
var{start:r}=WebQit.Webflo,e={},o={bundle_filename:"bundle.js",public_base_url:"/",spa_routing:!0,address_bar_synchrony:"standard",oohtml_support:"full",service_worker_support:!0,worker_scope:"/",worker_filename:"worker.js",routing:{root:"/",subroots:["/page-2","/page-4/subpage"],targets:2}};r.call({layout:e,params:o});
